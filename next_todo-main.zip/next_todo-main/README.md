
## インストール
```bash
npm install
```

## サーバ起動
```bash
npm run dev
```

## TODOデータフォルダ作成
```bash
data/
```
